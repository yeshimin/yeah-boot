CREATE DATABASE  IF NOT EXISTS `yeah_boot` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `yeah_boot`;
-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: devops    Database: yeah_boot
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_user`
--

DROP TABLE IF EXISTS `app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `mobile` varchar(16) NOT NULL COMMENT '手机号',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '登录密码',
  `account` varchar(16) NOT NULL DEFAULT '' COMMENT '账号',
  `nickname` varchar(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `gender` tinyint NOT NULL DEFAULT '0' COMMENT '性别：0-未知 1-男性 2-女性',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `__m57_uk_app_user_mobile_active_1` varchar(16) GENERATED ALWAYS AS (if(((`deleted` = 0) and (`mobile` <> _utf8mb4'')),`mobile`,NULL)) STORED,
  `__m57_uk_app_user_account_active_1` varchar(16) GENERATED ALWAYS AS (if(((`deleted` = 0) and (`account` is not null) and (char_length(`account`) > 0)),`account`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_app_user_mobile_active` (`__m57_uk_app_user_mobile_active_1`),
  UNIQUE KEY `uk_app_user_account_active` (`__m57_uk_app_user_account_active_1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='app端用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_city`
--

DROP TABLE IF EXISTS `area_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_city` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_code` char(2) NOT NULL COMMENT '父级编码',
  `code` char(4) NOT NULL COMMENT '编码',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `__m57_uk_area_city_code_active_1` char(4) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_area_city_code_active` (`__m57_uk_area_city_code_active_1`),
  KEY `idx_area_city_parent_code_deleted` (`parent_code`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='城市表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_district`
--

DROP TABLE IF EXISTS `area_district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_district` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_code` char(4) NOT NULL COMMENT '父级编码',
  `code` char(6) NOT NULL COMMENT '编码',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `__m57_uk_area_district_code_active_1` char(6) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_area_district_code_active` (`__m57_uk_area_district_code_active_1`),
  KEY `idx_area_district_parent_code_deleted` (`parent_code`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2980 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='区县表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_province`
--

DROP TABLE IF EXISTS `area_province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_province` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `code` char(2) NOT NULL COMMENT '编码',
  `name` varchar(8) NOT NULL COMMENT '名称',
  `__m57_uk_area_province_code_active_1` char(2) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_area_province_code_active` (`__m57_uk_area_province_code_active_1`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='省份表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_street`
--

DROP TABLE IF EXISTS `area_street`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_street` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_code` char(6) NOT NULL COMMENT '父级编码',
  `code` char(9) NOT NULL COMMENT '编码',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `__m57_uk_area_street_code_active_1` char(9) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_area_street_code_active` (`__m57_uk_area_street_code_active_1`),
  KEY `idx_area_street_parent_code_deleted` (`parent_code`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=41353 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='街道表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_village`
--

DROP TABLE IF EXISTS `area_village`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `area_village` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_code` char(9) NOT NULL COMMENT '父级编码',
  `code` char(12) NOT NULL COMMENT '编码',
  `name` varchar(64) NOT NULL COMMENT '名称',
  `__m57_uk_area_village_code_active_1` char(12) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_area_village_code_active` (`__m57_uk_area_village_code_active_1`),
  KEY `idx_area_village_parent_code_deleted` (`parent_code`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=620574 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='乡村表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_sms_api_log`
--

DROP TABLE IF EXISTS `notif_sms_api_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_sms_api_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `request` varchar(1024) NOT NULL DEFAULT '' COMMENT '请求参数',
  `response` varchar(2048) NOT NULL DEFAULT '' COMMENT '响应结果',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知-短信API日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `group_code` varchar(32) NOT NULL DEFAULT '' COMMENT '参数分组编码',
  `config_key` varchar(128) NOT NULL COMMENT '参数键',
  `config_name` varchar(64) NOT NULL COMMENT '参数名称',
  `config_value` varchar(1024) NOT NULL DEFAULT '' COMMENT '参数值',
  `value_type` tinyint NOT NULL DEFAULT '1' COMMENT '值类型：1-字符串 2-整数 3-长整数 4-布尔值',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `public_access` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否允许匿名公开访问：1-是 0-否',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序：自然数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_config_key_delete_time` (`config_key`,`delete_time`),
  KEY `idx_sys_config_group_status` (`group_code`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统参数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dict`
--

DROP TABLE IF EXISTS `sys_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父ID',
  `code` varchar(32) NOT NULL COMMENT '编码',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `value` varchar(16) NOT NULL DEFAULT '' COMMENT '值',
  `level` int NOT NULL COMMENT '层级',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序：大于等于1',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_dict_parent_code_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_dict_parent_code_active_2` varchar(32) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  `__m57_uk_sys_dict_parent_name_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_dict_parent_name_active_2` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_dict_parent_code_active` (`__m57_uk_sys_dict_parent_code_active_1`, `__m57_uk_sys_dict_parent_code_active_2`),
  UNIQUE KEY `uk_sys_dict_parent_name_active` (`__m57_uk_sys_dict_parent_name_active_1`, `__m57_uk_sys_dict_parent_name_active_2`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统字典表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `storage_type` int NOT NULL COMMENT '存储类型',
  `base_path` varchar(255) NOT NULL DEFAULT '' COMMENT '基础路径（只有本地存储才有）',
  `bucket` varchar(64) NOT NULL COMMENT 'bucket',
  `path` varchar(64) NOT NULL DEFAULT '' COMMENT '路径（可为空）',
  `file_key` varchar(64) NOT NULL COMMENT '文件key（无后缀）',
  `suffix` varchar(16) NOT NULL DEFAULT '' COMMENT '文件后缀（可为空）',
  `original_name` varchar(64) NOT NULL COMMENT '原始文件名',
  `__m57_uk_sys_file_key_active_1` varchar(64) GENERATED ALWAYS AS (if((`deleted` = 0),`file_key`,NULL)) STORED,
  `__m57_uk_sys_file_file_key_active_1` varchar(64) GENERATED ALWAYS AS (if((`deleted` = 0),`file_key`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_file_key_active` (`__m57_uk_sys_file_key_active_1`),
  UNIQUE KEY `uk_sys_file_file_key_active` (`__m57_uk_sys_file_file_key_active_1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统文件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `trigger_type` tinyint NOT NULL DEFAULT '1' COMMENT '触发类型：1-系统触发 2-用户触发',
  `category` tinyint NOT NULL DEFAULT '0' COMMENT '事件类型：0-无 1-鉴权相关 2-数据操作 3-定时任务 4-上传下载',
  `client_ip` varchar(45) DEFAULT NULL COMMENT '客户端IP',
  `event` varchar(32) DEFAULT NULL COMMENT '事件',
  `input` varchar(255) DEFAULT NULL COMMENT '输入',
  `output` varchar(512) DEFAULT NULL COMMENT '输出',
  `time` int DEFAULT NULL COMMENT '耗时（毫秒）',
  `success` varchar(8) DEFAULT NULL COMMENT '是否成功',
  `extra` varchar(255) DEFAULT NULL COMMENT '额外信息（json字符串）',
  `comment` varchar(255) DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`id`),
  KEY `idx_sys_log_client_ip` (`client_ip`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_org`
--

DROP TABLE IF EXISTS `sys_org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_org` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序：自然数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_org_parent_name_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_org_parent_name_active_2` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_org_parent_name_active` (`__m57_uk_sys_org_parent_name_active_1`, `__m57_uk_sys_org_parent_name_active_2`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统组织表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_post`
--

DROP TABLE IF EXISTS `sys_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_post` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `code` varchar(16) NOT NULL DEFAULT '' COMMENT '编码',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `sort` int DEFAULT '1' COMMENT '排序：自然数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_post_code_active_1` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  `__m57_uk_sys_post_name_active_1` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_post_code_active` (`__m57_uk_sys_post_code_active_1`),
  UNIQUE KEY `uk_sys_post_name_active` (`__m57_uk_sys_post_name_active_1`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统岗位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_res`
--

DROP TABLE IF EXISTS `sys_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_res` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `type` tinyint NOT NULL COMMENT '类型：1-菜单 2-页面 3-按钮 4-接口 5-分组',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父ID',
  `group_id` bigint NOT NULL DEFAULT '0' COMMENT '接口资源分组ID，仅接口资源使用',
  `name` varchar(16) NOT NULL COMMENT '名称（父下唯一）',
  `permission` varchar(128) NOT NULL DEFAULT '' COMMENT '权限标识（全局唯一）',
  `path` varchar(32) NOT NULL DEFAULT '' COMMENT '前端路径',
  `component` varchar(32) NOT NULL DEFAULT '' COMMENT '前端组件',
  `icon` varchar(16) NOT NULL DEFAULT '' COMMENT '图标',
  `is_link` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否外链',
  `link_url` varchar(255) NOT NULL DEFAULT '' COMMENT '外链地址',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `visible` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否可见：1-是 0-否',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序：自然数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_res_permission_active_1` varchar(128) GENERATED ALWAYS AS (if(((`deleted` = 0) and (`permission` <> _utf8mb4'')),`permission`,NULL)) STORED,
  `__m57_uk_sys_res_view_name_active_1` bigint GENERATED ALWAYS AS (if(((`deleted` = 0) and (`type` <> 4)),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_res_view_name_active_2` varchar(16) GENERATED ALWAYS AS (if(((`deleted` = 0) and (`type` <> 4)),`name`,NULL)) STORED,
  `__m57_uk_sys_res_api_name_active_1` bigint GENERATED ALWAYS AS (if(((`deleted` = 0) and (`type` = 4)),`group_id`,NULL)) STORED,
  `__m57_uk_sys_res_api_name_active_2` varchar(16) GENERATED ALWAYS AS (if(((`deleted` = 0) and (`type` = 4)),`name`,NULL)) STORED,
  `__m57_uk_sys_res_parent_name_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_res_parent_name_active_2` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_res_permission_active` (`__m57_uk_sys_res_permission_active_1`),
  UNIQUE KEY `uk_sys_res_view_name_active` (`__m57_uk_sys_res_view_name_active_1`, `__m57_uk_sys_res_view_name_active_2`),
  UNIQUE KEY `uk_sys_res_api_name_active` (`__m57_uk_sys_res_api_name_active_1`, `__m57_uk_sys_res_api_name_active_2`),
  UNIQUE KEY `uk_sys_res_parent_name_active` (`__m57_uk_sys_res_parent_name_active_1`, `__m57_uk_sys_res_parent_name_active_2`)
) ENGINE=InnoDB AUTO_INCREMENT=20349 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统资源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_res_group`
--

DROP TABLE IF EXISTS `sys_res_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_res_group` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '更新者',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父分组ID',
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分组名称',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_res_group_parent_name_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`parent_id`,NULL)) STORED,
  `__m57_uk_sys_res_group_parent_name_active_2` varchar(64) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_res_group_parent_name_active` (`__m57_uk_sys_res_group_parent_name_active_1`, `__m57_uk_sys_res_group_parent_name_active_2`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2305 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='接口资源分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_res_mount`
--

DROP TABLE IF EXISTS `sys_res_mount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_res_mount` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '更新者',
  `view_res_id` bigint NOT NULL COMMENT '视图/分组资源ID',
  `api_res_id` bigint NOT NULL COMMENT '接口资源ID',
  `sort` int NOT NULL DEFAULT '1' COMMENT '排序',
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_res_mount_pair_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`view_res_id`,NULL)) STORED,
  `__m57_uk_sys_res_mount_pair_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`api_res_id`,NULL)) STORED,
  `__m57_uk_sys_res_mount_view_api_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`view_res_id`,NULL)) STORED,
  `__m57_uk_sys_res_mount_view_api_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`api_res_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_res_mount_pair_active` (`__m57_uk_sys_res_mount_pair_active_1`, `__m57_uk_sys_res_mount_pair_active_2`),
  UNIQUE KEY `uk_sys_res_mount_view_api_active` (`__m57_uk_sys_res_mount_view_api_active_1`, `__m57_uk_sys_res_mount_view_api_active_2`),
  KEY `idx_view_res_id` (`view_res_id`),
  KEY `idx_api_res_id` (`api_res_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='资源接口挂载表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `code` varchar(16) NOT NULL DEFAULT '' COMMENT '编码',
  `name` varchar(16) NOT NULL COMMENT '名称',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_role_code_active_1` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`code`,NULL)) STORED,
  `__m57_uk_sys_role_name_active_1` varchar(16) GENERATED ALWAYS AS (if((`deleted` = 0),`name`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_role_code_active` (`__m57_uk_sys_role_code_active_1`),
  UNIQUE KEY `uk_sys_role_name_active` (`__m57_uk_sys_role_name_active_1`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_role_res`
--

DROP TABLE IF EXISTS `sys_role_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_res` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `res_id` bigint NOT NULL COMMENT '资源ID',
  `mount_id` bigint NOT NULL DEFAULT '0' COMMENT '挂载ID；0表示非挂载授权',
  `__m57_uk_sys_role_res_relation_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`role_id`,NULL)) STORED,
  `__m57_uk_sys_role_res_relation_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`res_id`,NULL)) STORED,
  `__m57_uk_sys_role_res_relation_active_3` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`mount_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_role_res_relation_active` (`__m57_uk_sys_role_res_relation_active_1`, `__m57_uk_sys_role_res_relation_active_2`, `__m57_uk_sys_role_res_relation_active_3`),
  KEY `idx_role_id_deleted` (`role_id`,`deleted`),
  KEY `idx_res_id_deleted` (`res_id`,`deleted`),
  KEY `idx_mount_id_deleted` (`mount_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=4936 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统角色与资源关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_storage`
--

DROP TABLE IF EXISTS `sys_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_storage` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `storage_type` int NOT NULL COMMENT '存储类型',
  `base_path` varchar(255) NOT NULL DEFAULT '' COMMENT '基础路径（只有本地存储才有）',
  `bucket` varchar(64) NOT NULL COMMENT 'bucket',
  `path` varchar(64) NOT NULL DEFAULT '' COMMENT '路径（可为空）',
  `file_key` varchar(64) NOT NULL COMMENT '文件key（无后缀）',
  `suffix` varchar(16) NOT NULL DEFAULT '' COMMENT '文件后缀（可为空）',
  `original_name` varchar(64) NOT NULL COMMENT '原始文件名',
  `is_public` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否公开',
  `is_used` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否被使用',
  `cleanable_time` datetime NOT NULL COMMENT '可清理时间',
  `__m57_uk_sys_storage_key_active_1` varchar(64) GENERATED ALWAYS AS (if((`deleted` = 0),`file_key`,NULL)) STORED,
  `__m57_uk_sys_storage_file_key_active_1` varchar(64) GENERATED ALWAYS AS (if((`deleted` = 0),`file_key`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_storage_key_active` (`__m57_uk_sys_storage_key_active_1`),
  UNIQUE KEY `uk_sys_storage_file_key_active` (`__m57_uk_sys_storage_file_key_active_1`),
  KEY `idx_sys_storage_cleanable` (`is_used`,`deleted`,`cleanable_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统存储表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL COMMENT '密码（加密）',
  `status` varchar(8) NOT NULL DEFAULT '1' COMMENT '状态：1-启用 2-禁用',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `mobile` varchar(16) NOT NULL DEFAULT '' COMMENT '手机号',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱',
  `gender` tinyint NOT NULL DEFAULT '0' COMMENT '性别：0-未知 1-男性 2-女性',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `__m57_uk_sys_user_username_active_1` varchar(32) GENERATED ALWAYS AS (if((`deleted` = 0),`username`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_user_username_active` (`__m57_uk_sys_user_username_active_1`),
  KEY `idx_sys_user_username_deleted` (`username`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user_org`
--

DROP TABLE IF EXISTS `sys_user_org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_org` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `org_id` bigint NOT NULL COMMENT '组织ID',
  `__m57_uk_sys_user_org_pair_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_org_pair_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`org_id`,NULL)) STORED,
  `__m57_uk_sys_user_org_relation_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_org_relation_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`org_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_user_org_pair_active` (`__m57_uk_sys_user_org_pair_active_1`, `__m57_uk_sys_user_org_pair_active_2`),
  UNIQUE KEY `uk_sys_user_org_relation_active` (`__m57_uk_sys_user_org_relation_active_1`, `__m57_uk_sys_user_org_relation_active_2`),
  KEY `idx_sys_user_org_user_deleted` (`user_id`,`deleted`),
  KEY `idx_sys_user_org_org_deleted` (`org_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户与组织关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user_post`
--

DROP TABLE IF EXISTS `sys_user_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_post` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `post_id` bigint NOT NULL COMMENT '岗位ID',
  `__m57_uk_sys_user_post_pair_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_post_pair_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`post_id`,NULL)) STORED,
  `__m57_uk_sys_user_post_relation_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_post_relation_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`post_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_user_post_pair_active` (`__m57_uk_sys_user_post_pair_active_1`, `__m57_uk_sys_user_post_pair_active_2`),
  UNIQUE KEY `uk_sys_user_post_relation_active` (`__m57_uk_sys_user_post_relation_active_1`, `__m57_uk_sys_user_post_relation_active_2`),
  KEY `idx_sys_user_post_user_deleted` (`user_id`,`deleted`),
  KEY `idx_sys_user_post_post_deleted` (`post_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户与岗位关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `delete_time` datetime NOT NULL DEFAULT '9999-12-31 23:59:59' COMMENT '删除时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：1-是 0-否',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(32) NOT NULL DEFAULT '' COMMENT '创建者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(32) NOT NULL DEFAULT '' COMMENT '更新者',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `__m57_uk_sys_user_role_pair_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_role_pair_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`role_id`,NULL)) STORED,
  `__m57_uk_sys_user_role_relation_active_1` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`user_id`,NULL)) STORED,
  `__m57_uk_sys_user_role_relation_active_2` bigint GENERATED ALWAYS AS (if((`deleted` = 0),`role_id`,NULL)) STORED,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sys_user_role_pair_active` (`__m57_uk_sys_user_role_pair_active_1`, `__m57_uk_sys_user_role_pair_active_2`),
  UNIQUE KEY `uk_sys_user_role_relation_active` (`__m57_uk_sys_user_role_relation_active_1`, `__m57_uk_sys_user_role_relation_active_2`),
  KEY `idx_sys_user_role_user_deleted` (`user_id`,`deleted`),
  KEY `idx_sys_user_role_role_deleted` (`role_id`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户与角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-14 21:45:01
